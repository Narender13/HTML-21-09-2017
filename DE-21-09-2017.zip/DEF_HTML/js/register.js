$(document).ready(function () {
    var registration = {
        registerFormRef: $("form[name='registration']"),
        event: function () {
            $("#registerClickEvent").on("click", this.register)
        },
        register: function () {
            if (registration.checkformValidity()) {
                console.log("Register");
                /*---------- Make a ajex call -----------------*/
            }
            else {
                console.log("Form not valid");
                return false;
            }
        },
        errorMessage: function () {
            return {
                firstname: {
                    nameText: "Please provide your firstname",
                    minlength: "Your firstname must be at least 3 characters long"
                },
                lastname: {
                    nameText: "Please provide your lastname",
                    minlength: "Your lastname must be at least 3 characters long"
                },
                companyName: {
                    nameText: "Please provide your Company name",
                    minlength: "Company name must be at least 3 characters long"
                },
                role: {
                    nameText: "Please provide your Company name",
                    minlength: "Company name must be at least 3 characters long"
                },
                email: {
                    nameText: "Please provide an  email address",
                },
            }
        },

        initializeRegisterForm: function () {
            this.registerFormRef.validate({// initialize plugin
                //by default validation will run on input keyup and focusout
                onkeypress: false,
                rules: {
                    // The key name on the left side is the name attribute
                    // of an input field. Validation rules are defined
                    // on the right side
                    firstname: {
                        required: true,
                        minlength: 3,
                    },
                    lastname: {
                        required: true,
                        minlength: 3,
                    },
                    companyName: {
                        required: true,
                        minlength: 3,
                    },
                    role: {
                        required: true,
                        minlength: 3,
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    password: {
                        required: true,
                        minlength: 8,
                        maxlength: 16,
                        validpassword: true
                    },
                    repassword: {
                        required: true,
                        minlength: 5,
                        passwordMatch: true
                    }
                },

                // Specify validation error messages
                messages: {
                    firstname: {
                        required: registration.errorMessage().firstname.nameText,
                        minlength: registration.errorMessage().firstname.minlength
                    },
                    lastname: {
                        required: registration.errorMessage().lastname.nameText,
                        minlength: registration.errorMessage().lastname.minlength
                    },
                    companyName: {
                        required: registration.errorMessage().companyName.nameText,
                        minlength: registration.errorMessage().companyName.minlength
                    },
                    role: {
                        required: registration.errorMessage().role.nameText,
                        minlength: registration.errorMessage().role.minlength
                    },
                    password: {
                        required: "Please provide a password",
                        minlength: "Password Must be 8 to 16 characters in length",
                        mxnlength: "Password Must be 8 to 16 characters in length",
                        validpassword: "Password must contain at least one letter and one number and a special character from"
                    },
                    repassword: {
                        required: "",
                        minlength: "Your password must be at least 5 characters long",
                        passwordMatch: "Your Passwords Must Match" // custom message for mismatched passwords
                    },
                    email: {
                        required: registration.errorMessage().email.nameText
                    },
                    // siteurl: "Please enter a valid URL"
                },

            });
            $.validator.addMethod('passwordMatch', function (value, element) {
                // The two password input
                var password = $("#register-password").val();
                var confirmPassword = $("#register-pass-confirm").val();
                // Check for equality with the password inputs
                if (password != confirmPassword) {
                    return false;
                } else {
                    return true;
                }

            }, "Your Passwords Must Match");
            $.validator.addMethod('validpassword', function (value, element) {
                var passwordPattern = new RegExp(/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d][A-Za-z\d!@#$%^&*()_+]{8,16}$/);
                var password = $("#register-password").val();  // Check for equality with the password inputs
                if (passwordPattern.test(password)) {
                    return true;
                } else {
                    return false;
                }

            }, "Your Passwords must match");
            $('input, select, radio, checkbox').keypress(function () {
                $("form[name='registration']").validate().element(this);
            });
        },
        checkformValidity: function () {
            if (this.registerFormRef.valid()) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    registration.event();
    registration.initializeRegisterForm();
});